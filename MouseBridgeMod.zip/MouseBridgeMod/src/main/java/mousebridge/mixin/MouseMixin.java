package net.fabricmc.example.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

@Mixin(Mouse.class)
public class MouseMixin {
    private static double incomingX = 0;
    private static double incomingY = 0;
    private static boolean threadStarted = false;
    private static final Object lock = new Object();

    @Inject(method = "updateMouse", at = @At("HEAD"), cancellable = true)
    private void onUpdateMouse(CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();

        // Start listening to network port 9999 for your AIDE app data
        if (!threadStarted) {
            threadStarted = true;
            Thread listenerThread = new Thread(() -> {
                try (DatagramSocket socket = new DatagramSocket(9999)) { 
                    byte[] buffer = new byte[1024];
                    while (true) {
                        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                        socket.receive(packet);
                        String msg = new String(packet.getData(), 0, packet.getLength());
                        String[] parts = msg.split(",");
                        if (parts.length == 2) {
                            synchronized (lock) {
                                incomingX += Double.parseDouble(parts[0]);
                                incomingY += Double.parseDouble(parts[1]);
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            listenerThread.setDaemon(true);
            listenerThread.start();
        }

        // Steer the game camera if playing in-world and menus are closed
        if (client.currentScreen == null && client.player != null) {
            double deltaX, deltaY;
            synchronized (lock) {
                deltaX = incomingX;
                deltaY = incomingY;
                incomingX = 0;
                incomingY = 0;
            }

            if (deltaX != 0 || deltaY != 0) {
                ClientPlayerEntity player = client.player;
                float sensitivity = 0.15f; // Tweak this up or down to adjust looking speed
                player.setYaw(player.getYaw() + (float) deltaX * sensitivity);
                player.setPitch(player.getPitch() + (float) deltaY * sensitivity);

                if (player.getPitch() < -90.0F) player.setPitch(-90.0F);
                if (player.getPitch() > 90.0F) player.setPitch(90.0F);
            }
            ci.cancel(); // Blocks native broken mouse tracking from running
        }
    }
}
