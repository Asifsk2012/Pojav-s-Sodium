
package net.caffeinemc.mods.sodium.client.compatibility.checks;

import net.caffeinemc.mods.sodium.client.compatibility.environment.GlContextInfo;
import net.caffeinemc.mods.sodium.client.compatibility.workarounds.nvidia.NvidiaWorkarounds;
import net.caffeinemc.mods.sodium.client.platform.NativeWindowHandle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PostLaunchChecks {
    private static final Logger LOGGER =
            LoggerFactory.getLogger("Sodium-PostlaunchChecks");

    public static void onContextInitialized(
            NativeWindowHandle window,
            GlContextInfo context
    ) {
        LOGGER.info("[Pojav Sodium] OpenGL context detected");
        LOGGER.info("[Pojav Sodium] Vendor: {}", context.vendor());
        LOGGER.info("[Pojav Sodium] Renderer: {}", context.renderer());
        LOGGER.info("[Pojav Sodium] Version: {}", context.version());

        GraphicsDriverChecks.postContextInit(window, context);

        NvidiaWorkarounds.applyContextChanges(context);

        LOGGER.info("[Pojav Sodium] Android compatibility checks completed");
    }
}
