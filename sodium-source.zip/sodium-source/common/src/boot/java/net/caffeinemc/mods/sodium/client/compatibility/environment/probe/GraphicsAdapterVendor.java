
package net.caffeinemc.mods.sodium.client.compatibility.environment.probe;

import net.caffeinemc.mods.sodium.client.compatibility.environment.GlContextInfo;
import org.jspecify.annotations.NonNull;

import java.util.Locale;
import java.util.regex.Pattern;

public enum GraphicsAdapterVendor {
    NVIDIA,
    AMD,
    INTEL,
    QUALCOMM,
    ARM,
    UNKNOWN;

    private static final Pattern INTEL_ICD_PATTERN =
            Pattern.compile(
                    "ig(4|7|75|8|9|11|12|(xe2?(hpg?|lpg?)))icd(32|64)\\.dll",
                    Pattern.CASE_INSENSITIVE
            );

    private static final Pattern NVIDIA_ICD_PATTERN =
            Pattern.compile("nvoglv(32|64)\\.dll", Pattern.CASE_INSENSITIVE);

    private static final Pattern AMD_ICD_PATTERN =
            Pattern.compile("(atiglpxx|atig6pxx)\\.dll", Pattern.CASE_INSENSITIVE);

    @NonNull
    static GraphicsAdapterVendor fromPciVendorId(String vendor) {
        if (vendor.contains("0x1002")) {
            return AMD;
        } else if (vendor.contains("0x10de")) {
            return NVIDIA;
        } else if (vendor.contains("0x8086")) {
            return INTEL;
        }

        return UNKNOWN;
    }

    @NonNull
    public static GraphicsAdapterVendor fromIcdName(String name) {
        if (matchesPattern(INTEL_ICD_PATTERN, name)) {
            return INTEL;
        } else if (matchesPattern(NVIDIA_ICD_PATTERN, name)) {
            return NVIDIA;
        } else if (matchesPattern(AMD_ICD_PATTERN, name)) {
            return AMD;
        }

        return UNKNOWN;
    }

    @NonNull
    public static GraphicsAdapterVendor fromContext(GlContextInfo context) {
        String vendor = context.vendor().toLowerCase(Locale.ROOT);
        String renderer = context.renderer().toLowerCase(Locale.ROOT);

        if (vendor.contains("qualcomm")
                || renderer.contains("adreno")) {
            return QUALCOMM;
        }

        if (vendor.contains("arm")
                || renderer.contains("mali")) {
            return ARM;
        }

        if (vendor.contains("nvidia")) {
            return NVIDIA;
        }

        if (vendor.contains("intel")) {
            return INTEL;
        }

        if (vendor.contains("amd")
                || vendor.contains("ati")) {
            return AMD;
        }

        return UNKNOWN;
    }

    private static boolean matchesPattern(Pattern pattern, String name) {
        return pattern.matcher(name).matches();
    }
}
