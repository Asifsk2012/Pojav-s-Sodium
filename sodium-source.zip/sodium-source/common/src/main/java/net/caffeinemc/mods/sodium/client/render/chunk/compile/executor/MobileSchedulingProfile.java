
package net.caffeinemc.mods.sodium.client.render.chunk.compile.executor;

/**
 * Pojav Sodium mobile scheduling configuration.
 *
 * Controls worker count and thread priority.
 * Does not replace Sodium's original job scheduler.
 */
public final class MobileSchedulingProfile {

    private static final int DEFAULT_WORKER_PRIORITY =
            Thread.NORM_PRIORITY - 2;

    private MobileSchedulingProfile() {
    }

    public static int getWorkerPriority() {
        return Math.max(
                Thread.MIN_PRIORITY,
                Math.min(
                        Thread.MAX_PRIORITY,
                        DEFAULT_WORKER_PRIORITY
                )
        );
    }

    public static int getWorkerLimit() {
        return MobilePerformanceProfile.getMaxChunkThreads();
    }

    public static boolean isMobileProfileEnabled() {
        return true;
    }
}
