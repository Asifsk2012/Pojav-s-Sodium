
package net.caffeinemc.mods.sodium.client.render.chunk.compile.executor;

/**
 * Pojav Sodium mobile performance profile.
 *
 * Uses the configured Java heap limit to select a
 * conservative chunk worker count.
 *
 * This class uses standard Java APIs only.
 */
public final class MobilePerformanceProfile {

    private MobilePerformanceProfile() {
    }

    public static int getMaxChunkThreads() {
        Runtime runtime = Runtime.getRuntime();

        int processors = Math.max(1, runtime.availableProcessors());

        long maxHeap = runtime.maxMemory();

        int memoryLimit;

        if (maxHeap <= 1024L * 1024L * 1024L) {
            memoryLimit = 1;
        } else if (maxHeap <= 2048L * 1024L * 1024L) {
            memoryLimit = 2;
        } else {
            memoryLimit = 3;
        }

        return Math.max(1, Math.min(processors, memoryLimit));
    }
}