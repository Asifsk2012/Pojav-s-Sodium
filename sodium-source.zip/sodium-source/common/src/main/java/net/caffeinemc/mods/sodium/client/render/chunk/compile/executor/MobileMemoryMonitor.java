
package net.caffeinemc.mods.sodium.client.render.chunk.compile.executor;

import org.apache.logging.log4j.Logger;

public final class MobileMemoryMonitor {

    private MobileMemoryMonitor() {
    }

    public static void logMemory(Logger logger) {
        Runtime runtime = Runtime.getRuntime();

        long used = runtime.totalMemory() - runtime.freeMemory();
        long allocated = runtime.totalMemory();
        long maximum = runtime.maxMemory();

        logger.info(
                "[Pojav Sodium] Memory: used={} MB, allocated={} MB, maximum={} MB",
                toMB(used),
                toMB(allocated),
                toMB(maximum)
        );
    }

    private static long toMB(long bytes) {
        return bytes / (1024L * 1024L);
    }
}
